function validPhoneNumber(phone) {
    var vnf_regex = /((09|03|07|08|05)+([0-9]{8}))/g;
    if (phone !== '') {
        if (vnf_regex.test(phone) == false)
            return false;
        return true;
    } else {
        return false;
    }
}

function validFullname(fullname) {
    let regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
    if(!regName.test(fullname)){
        return false;
    } else{
        return true;
    }
}

function validUserName(username) {
    let usernameRegex = /^[a-zA-Z0-9]+$/;
    let validUsername = username.match(usernameRegex);
    return validUsername != null;
};

/**
 * param: email
 * return bolean
 */
function validEmail(email){
    const re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    return re.test(String(email).toLowerCase());
}

$(document).ready(function () {
    $('body').addClass('loaded');
    $('#global-loader').fadeOut();

    Fancybox.bind(".fancybox", {
        on: {
            ready: (fancybox) => {
                console.log(`fancybox #${fancybox.id} is ready!`);
            }
        }
    });
});
